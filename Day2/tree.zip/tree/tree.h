#ifndef TREE_H
#define TREE_H

#include <vector>

std::vector<int> tree(int N, std::vector<std::pair<int,int> > E, int M, int L);

int ask(int x, int d, int v);

#endif

