#include "tree.h"
#include <vector>
std::vector<int> tree(int N, std::vector<std::pair<int,int> > E, int M, int L){
	int val=ask(1,0,1);
	return {0,val};
}
