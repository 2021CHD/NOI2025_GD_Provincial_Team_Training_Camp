#include<bits/stdc++.h>
#include "tree.h"
using namespace std;
namespace _174{//
	const int N=50005;
	void report(const string &s) { cout << s << endl, exit(0); }
	int n,m,l,i,a[N],s1,s2,cnt;
	vector<pair<int,int> > E;
	vector<int> G[N];
	int sz[N],sm[N],dis[N][20],SZ[N];
	bool cut[N];
	int Size(int x,int fa){
		sz[x]=1,sm[x]=0;
		for(auto j:G[x]) if(j^fa&&!cut[j]) sz[x]+=Size(j,x),sm[x]=max(sm[x],sz[j]);
		return sz[x];
	}
	int Core(int u,int fa,int T){
		int ret=u,mn=max(sm[u],T-sz[u]);
		for(auto j:G[u]) if(j^fa&&!cut[j]){
			int x=Core(j,u,T),y=max(sm[x],T-sz[x]);
			if(y<mn) mn=y,ret=x;
		}
		return ret;
	}
	unsigned short buf[N<<10],*sum1[N],*sum2[N],*lst=buf;
	int RT;
	int fa[N];
	void dfs(int x,int fa,int d){
		if(d) sum2[RT][dis[x][d-1]-1<<5|a[x]]++;
		sum1[RT][(dis[x][d]=~fa?dis[fa][d]+1:0)<<5|a[x]]++;
		for(auto j:G[x]) if(j^fa&&!cut[j]) dfs(j,x,d);
	}
	int solv(int x,int d){
		int T=Size(x,-1),c=Core(x,-1,T);
		cut[c]=1;RT=c;SZ[c]=T;
		sum1[RT]=lst,lst=lst+(T<<5);
		if(d) sum2[RT]=lst,lst=lst+(T<<5);
		dfs(c,-1,d);
		for(auto j:G[c]) if(!cut[j]) fa[solv(j,d+1)]=c;
		return c;
	}
	int st[N],top;
	int ask(int x,int d,int v){
		if(x<0||x>=n||d<l||d>n||v<0||v>=32) report("Invalid query.");
		++cnt;if(cnt>m) report("Too many queries.");
		st[top=0]=x;
		while(~st[top]) st[top+1]=fa[st[top]],++top;
		reverse(st,st+top);
		int ans=0;
		for(int j=0;j<top;j++){
			int u=dis[x][j];
			if(u<=d){
				int tmp=ans;
				if(d-u<SZ[st[j]]) ans+=sum1[st[j]][d-u<<5|v];
				if(j<top-1&&u^d&&d-u<=SZ[st[j+1]]) ans-=sum2[st[j+1]][d-u-1<<5|v];
			}
		}
		return ans;
	}
	int mian(){
		scanf("%d%d%d",&n,&m,&l);
		scanf("%d",&s1);E.resize(n-1);
		if(s1){
			mt19937 gen(s1);
			for(i=1;i<n;i++)
				E[i-1]={gen()%i,i};
		}
		else for(i=0;i<n-1;i++)
			scanf("%d%d",&E[i].first,&E[i].second);
		scanf("%d",&s2);
		if(s2){
			mt19937 gen(s2);
			for(i=0;i<n;i++) a[i]=gen()&31;
		}
		else for(i=0;i<n;i++) scanf("%d",&a[i]);
		for(i=0;i<n-1;i++){
			int x=E[i].first,y=E[i].second;
			G[x].emplace_back(y);
			G[y].emplace_back(x);
		}
		fa[solv(0,0)]=-1;
		int len=lst-buf;
		for(int j=1;j<len;j++) if(j&31) buf[j]+=buf[j-1];
		vector<int> ret=tree(n,E,m,l);
		if(ret.size()!=n) report("Wrong Answer.");
		for(int i=0;i<n;i++) if(a[i]^ret[i]) report("Wrong Answer");
		printf("Correct. %d queries.\n",cnt);
		return 0;
	}
}
int ask(int x,int d,int v){
	return _174::ask(x,d,v);
}
int main(int argc,char **argv){
	return _174::mian();
}
