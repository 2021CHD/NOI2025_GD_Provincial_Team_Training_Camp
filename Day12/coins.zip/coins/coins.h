#include <vector>
int solve(std::vector<int> a);
long long weigh(std::vector<int> p);